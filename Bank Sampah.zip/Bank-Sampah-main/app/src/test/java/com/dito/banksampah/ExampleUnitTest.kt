package com.dito.banksampah

import org.junit.Assert
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        Assert.assertEquals(4, (2 + 2).toLong())
    }
}